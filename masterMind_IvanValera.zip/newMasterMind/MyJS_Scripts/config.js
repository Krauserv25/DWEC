/*
	DESCRIPCION: SCRIPT QUE TRATA LAS VARIABLES GLOBALES
	AUTOR: IVAN VALERA
*/

var config = 
{
	debug: false, //Varaible global que indica si está activo el modo debug o no
	combOculta: null, //Variable global que almacena la combinación secreta
	currentFilaNum: 1 //Variable global que indica el contador de intentos actuales
};