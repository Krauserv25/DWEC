/*
	DESCRIPCION: SCRIPT QUE TRATA LAS VARIABLES GLOBALES
	AUTOR: IVAN VALERA
*/

var config = 
{
	debug: false //Varaible global que indica si está activo el modo debug o no
};