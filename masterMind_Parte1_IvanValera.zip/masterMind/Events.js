/*
	DESCRIPCION: SCRIPT QUE TRATA LOS EVENTOS PRODUCIDOS EN EL JUEGO
	AUTOR: IVAN VALERA
*/

//Eventos que se cargarán y asignarán una vez cargado el DOM
$(document).ready(function()
{
	//Evento focus para la caja rápida
		//Evento keydown para la caja rápida

	//Evento click para botón "Dame Pistas"

	//Evento "change" (aún no conozco el nombre) para el slider
});