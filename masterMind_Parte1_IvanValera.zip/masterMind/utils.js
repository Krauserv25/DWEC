/*
	DESCRIPCION: SCRIPT QUE TRATA LAS FUNCIONES O MÉTODOS ÚTILES ASÍ COMO CÁLCULOS O PROCESOS SECUNDARIOS
	AUTOR: IVAN VALERA
*/

var utils = 
{
	//Método que sirve para debugar y facilitar el seguimiento del proceso al programador
	alert: function()
	{
		//Paso 1: Mostrar los datos para debugar
	}
};