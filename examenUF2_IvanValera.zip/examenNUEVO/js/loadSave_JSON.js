
//Función que lee el contenido del archivo seleccionado
function readJsonFile(evt) 
{
	var fileJSON;

	var files = document.getElementById('loadJSON').files;

	if (!files.length) 
	{
	  alert('Debes seleccionar un archivo .json');
	  return;
	}
	else
	{
		var fileJSON = files[0];
		var auxSplit = files[0].name.split('.');

		if (auxSplit[1] != "json")
		{
			alert('Debes seleccionar un archivo .json');
			return;
		}
	}
	      
	var start = parseInt(0);
	var stop = parseInt(fileJSON.size - 1);

	var reader = new FileReader();

	// If we use onloadend, we need to check the readyState.
	reader.onloadend = function(evt) 
	{
	  if (evt.target.readyState == FileReader.DONE) 
	  {
	  	var auxPartida = JSON.parse(evt.target.result);
	  	loadPartida(auxPartida);
	  }
	};

	var blob = fileJSON.slice(start, stop + 1);
	reader.readAsBinaryString(blob);
}

//Función que empieza un nuevo juego con los datos almacenados de la partida guardada
function loadPartida (partida)
{
	var nombrePartida = partida.nombre;
	var personajes = partida.personajes;

	Juego = new JuegoFN(nombrePartida);

	var totalPersonajes = parseInt(personajes.length);

	var i;
	for (i = 0; i < totalPersonajes; i++)
	{
		if (personajes.raza === "Guerrero")
		{
			partida.personajes[i] = new personajeFN(personajes.nombre, personajes.apellidos,
			 personajes.raza, parseInt(personajes.nvMagia), parseInt(personajes.nvFuerza), parseInt(personajes.nvIntel), Juego.comportamiento.calculateGuerrero);
		}
		else
		{
			partida.personajes[i] = new personajeFN(personajes.nombre, personajes.apellidos,
			 personajes.raza, parseInt(personajes.nvMagia), parseInt(personajes.nvFuerza), parseInt(personajes.nvIntel), Juego.comportamiento.calculateMago);			
		}

		partida.personajes[i].calculateAttack();
	}

	showInfoGame();
	Juego.listPersonajes();
	prepareToSavePartida();	
}

function prepareToSavePartida ()
{
	var code = "";

	$("#linkJSON").remove();
	var jsonPartida = JSON.stringify(Juego); //Convertimos el objeto que deseamos en json

	//Esto sirve para indicar que los datos en json van a ser almacenados en un archivo
	var data = "text/json;charset=utf-8," + encodeURIComponent(jsonPartida); 

	//Genera el enlace de descarga del archivo con los datos en json
	code += '<a id="linkJSON" href="#" download="examenPartida.json" onclick="prepareToSavePartida();">SAVE GAME</a>';

	$("#divSaveLoad").append(code);
	$("#linkJSON").attr("href", "data:"+data);
}